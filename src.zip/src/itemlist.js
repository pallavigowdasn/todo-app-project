
import { useState, useEffect } from "react";
import swal from 'sweetalert';
import {Link} from "react-router-dom";


const Allitem = () =>{
    let[myitem, updateItem] = useState([]);

    const getItem = () =>{
        updatekeyword(""); // it will empty the search textbox
        fetch("http://localhost:1111/itemlist")
        .then(response=>response.json())
        .then(itemArray=>{
            updateItem(itemArray.reverse());
        })
    }

    useEffect(()=>{
        getItem();
    },[1]);
    const deleteItem = (id)=>{
        let url="http://localhost:1111/itemlist/"+id;
        let postdata={method:"delete"};
        fetch(url,postdata)
        .then(response=>response.json())

        .then(serverinfo=>{
            swal("Deleted",serverinfo.msg,"success");
            getItem();
        })
    }
    let[keyword,updatekeyword]=useState("");
    const serachItem=()=>{
        let url="http://localhost:1111/searchapi";
        let newitem={
         "mykeyword":keyword
         
        };
        let postdata={
         headers:{'Content-Type':'Application/json'},
         method:"PUT",
         body:JSON.stringify(newitem)
        }
        if(newitem.mykeyword !="" )
        {
        fetch(url,postdata)
        .then(response=>response.json())
        .then(itemarray=>{
            updateItem(itemarray);
         
 
        })
     }else{
         swal("Invalid Request ","Please enter  search keyword","warning");
     }
    }

    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-8 mb-5">
                    <h3 className="text-center"> Item List : {myitem.length} </h3>
                </div>
                <div className="col-lg-4 mb-5">
                    <label>Search</label>
                    <div className="input-group">
                        <input type="text" className="form-control" onChange={obj=>updatekeyword(obj.target.value)}
                        value={keyword}/>
                        <button className="btn btn-success" onClick={serachItem}>serach</button>
                        <button className="btn btn-warning" onClick={getItem}>Reset</button>
                    </div>
                </div>
                {
                    myitem.map((item, index)=>{
                        return(
                            <div className="mb-4 col-lg-3" key={index}>
                                <div className="p-3 border rounded">
                                    <h4> {item.itemname} </h4>
                                    <p> Rs. {item.itemprice} </p>
                                    <p> {item.itemdetails} </p>
                                    <p className="text-center">
                                        <button className="btn btn-danger btn-sm" onClick={deleteItem.bind(this,item._id)}>
                                             Delete
                                        </button>
                                        <Link className="btn btn-warning ms-2" to={`/edititem/${item._id} `}>edit</Link>
                                    </p>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </div>
    )
}

export default Allitem;