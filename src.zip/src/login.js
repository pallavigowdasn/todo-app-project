import {useState} from "react";
const Mylogin=()=>{
    let[emailid,pickEmail]=useState("");
    let[password,pickPassword]=useState("");
    let[message,updateMessage]=useState("enter your Login details");


    const logincheck=()=>{
       if(emailid==""|| password=="")
       {
        updateMessage("empty email of password!");
       }else{
        updateMessage("please wait validating....");
        let url="http://localhost:1111/auth";
        let input={"emailid":emailid,'password':password};
        let postdata={
            headers:{'Content-Type':'application/json'},
            method:'POST',
            body:JSON.stringify(input)
        }
        fetch(url,postdata)
        .then(response=>response.json())
        .then(userArray=>{
            if(userArray.length==0)
            {
                updateMessage('invalid or not exists !');
            }else{
                updateMessage('Success:Redirecting....');
                localStorage.setItem("usertoken",userArray[0]._id);
                localStorage.setItem("fullname",userArray[0].fullname);
                window.location.reload();
            }
        })
       }
    }

    return(
         <div className="container mt-5">
            <div className="row">
                <div className="col-lg-4"> </div>
                <div className="col-lg-4">
                    <div className="p-4 rounded shadow-lg">
                        <h3 className="text-center text-danger mb-4">Admin login</h3>
                        <p className="text-center">{message}</p>
                        <div className="mb-3">
                            <label>e-mail id </label>
                            <input type="email" placeholder="enter email id" className="form-control"
                            onChange={obj=>pickEmail(obj.target.value)} value={emailid}/>

                        </div>
                        <div className="mb-3">
                            <label>password </label>
                            <input type="password" placeholder="enter password" className="form-control"
                            onChange={obj=>pickPassword(obj.target.value)} value={password}/>

                        </div>
                        <div className="text-center">
                            <button className="btn btn-danger" onClick={logincheck}> Login</button>

                        </div>
                    </div>
                </div>
                <div className="col-lg-4"></div>

            </div>
         </div>
    )
}
export default Mylogin;