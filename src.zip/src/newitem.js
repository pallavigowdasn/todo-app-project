import { useEffect, useState } from "react";
import swal from "sweetalert";
const Mynewitem=()=>{
    let[productname,pickname]=useState("");
    let[productprice,pickprice]=useState("");
    let[productdetails,pickdetails]=useState("");
    const save=()=>{
       let url="http://localhost:1111/itemlist";
       let newitem={
        "name":productname,
        "price":productprice,
        "details":productdetails
       };
       let postdata={
        headers:{'Content-Type':'Application/json'},
        method:"POST",
        body:JSON.stringify(newitem)
       }
       if(newitem.name !=""  && newitem.price !="" && newitem.details !="")
       {
       fetch(url,postdata)
       .then(response=>response.json())
       .then(iteminfo=>{
        swal(productname,"save Successfully ","success");
        pickname("");
        pickprice("");
        pickdetails("");
        window.location.href="../#";

       })
    }else{
        swal("Invalid Input","Please enter  values","warning");
    }
        
    }
    return(
        <div className="container">
            <div className="row">
                <div className="col-lg-4">

                </div>
                <div className="col-lg-4">
                    <form>
                        <h3 className="text-center mb-3">enter item details</h3>
                        <div className="mb-4">
                            <label>enter item name</label>
                            <input type="text" className="form-control" onChange={obj=>pickname(obj.target.value)}
                            value={productname}/>

                        </div>
                        <div className="mb-4">
                            <label>enter item price</label>
                            <input type="number" className="form-control" onChange={obj=>pickprice(obj.target.value)}
                            value={productprice}/>

                        </div>
                        <div className="mb-4">
                            <label>enter item details</label>
                            <textarea className="form-control"   onChange={obj=>pickdetails(obj.target.value)}
                            value={productdetails}></textarea>

                        </div>
                        <div className="text-center">
                            <button type="button" className="btn btn-info me-3" onClick={save}>Save</button>
                            <button type="reset" className="btn btn-danger">clear all</button>
                        </div>
                    </form>
                </div>
                <div className="col-lg-4">

                </div>
            </div>

        </div>
    )
}
export default Mynewitem;